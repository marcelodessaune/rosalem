﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Classes
{
    internal abstract class Professor
    {
        private string nome { get; set; }

        private int matricula { get; set; }

        private int cargaHoraria { get; set; }

        private double beneficio { get; set; }

        public virtual void calcularBeneficio() => Console.WriteLine("Professor: Calculou Beneficio");

        public double getBeneficio()
        {
            return beneficio;
        }
    }
}
