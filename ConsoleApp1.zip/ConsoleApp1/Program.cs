﻿using ConsoleApp1.Classes;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" == ProfDE ==");
            ProfDE pd = new ProfDE();
            pd.calcularBeneficio();

            Console.WriteLine(" == ProfHorista ==");
            ProfHorista ph = new ProfHorista(); 
            ph.calcularBeneficio(); 
        }
    }
}
