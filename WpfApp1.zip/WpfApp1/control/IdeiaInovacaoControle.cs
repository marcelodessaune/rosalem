﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.Model;

namespace WpfApp1.control
{
    internal class IdeiaInovacaoControle
    {
        private IdeiaInovacao ModeloPersistencia = new();
        public Boolean ControleCadstraIdeiaInovacao(string area, string ideia, float custo)
        {
            ideia = ideia + "!!!!";

            IdeiaInovacao ii = new()
            {
                Area = area,
                Ideia = ideia,
                Custo = custo
            };

            return ModeloPersistencia.CadastrarIdeiaInovacao(ii);
            
            //if(ModeloPersistencia.CadastrarIdeiaInovacao(ii))
               // return true;
              // return false;
        }
    }
}
