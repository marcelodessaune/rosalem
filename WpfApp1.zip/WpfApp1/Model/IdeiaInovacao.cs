﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.persistencia;

namespace WpfApp1.Model
{
    internal class IdeiaInovacao
    {
        public String Area { get; set; } =  "";

        public String Ideia { get; set; } = "";

        public float Custo { get; set; } = 0;

        public Boolean CadastrarIdeiaInovacao(IdeiaInovacao i)
        {
            BD.SalvarBD(i);

            return true;
        }


    }
}
