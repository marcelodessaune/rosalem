﻿using System.Diagnostics;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1.control;
using WpfApp1.persistencia;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        private IdeiaInovacaoControle objClasseIdeiaInovacao = new();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void buttonCadastrar_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtArea.Text) &&
                !string.IsNullOrEmpty(txtDescreva.Text))
            {

                if (objClasseIdeiaInovacao.ControleCadstraIdeiaInovacao(txtArea.Text,
                                                                    txtDescreva.Text,
                                                                    float.Parse(txtCusto.Text)))

                    MessageBox.Show("Cadastro realizado com sucesso");
            }
            else
                MessageBox.Show("Campos obrigatorios devem ser preenchidos");


            Debug.WriteLine("=============");
            BD.RetornarBD().ForEach(x => Debug.WriteLine(x));  
            Debug.WriteLine("=============");
        }
    }
}