﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UVV_Fintech_Avançada.Model
{
    public class Depositar : ITransacao
    {
        private Conta conta;

        public Depositar(Conta conta)
        {
            this.conta = conta;
        }

        public void Executar(double valor)
        {
            conta.Depositar(valor);
        }
    }
}
