﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UVV_Fintech_Avançada.Model
{
    class GerenciadorDeContas
    {
    }
}
