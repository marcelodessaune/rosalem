﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UVV_Fintech_Avançada.Model
{
    public class Transferir : ITransacao
    {
        private string ContaOrigem;
        private string ContaDestino;
        private double SaldoOrigem;
        private double SaldoDestino;

        public Transferir(string contaOrigem, string contaDestino, double saldoOrigem, double saldoDestino)
        {
            ContaOrigem = contaOrigem;
            ContaDestino = contaDestino;
            SaldoOrigem = saldoOrigem;
            SaldoDestino = saldoDestino;
        }

        public void Executar(double valor)
        {
            if (valor <= 0)
            {
                Console.WriteLine("Valor de transferência inválido.");
                return;
            }

            if (SaldoOrigem >= valor)
            {
                SaldoOrigem -= valor;
                SaldoDestino += valor;
                Console.WriteLine($"Transferência de {valor:C} realizada com sucesso!");
                Console.WriteLine($"Saldo Atual - Conta Origem: {SaldoOrigem:C}, Conta Destino: {SaldoDestino:C}");
            }
            else
            {
                Console.WriteLine("Saldo insuficiente na conta de origem.");
            }
        }
        public string GetDescricao()
        {
            return $"Transferência entre a conta {ContaOrigem} e {ContaDestino}.";
        }

        public double GetSaldoOrigem()
        {
            return SaldoOrigem;
        }

        public double GetSaldoDestino()
        {
            return SaldoDestino;
        }
    }
}
