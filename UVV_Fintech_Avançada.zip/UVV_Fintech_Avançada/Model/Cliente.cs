﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UVV_Fintech_Avançada.Model
{
    public class Cliente
    {
        public string Nome { get; set; }
        public string ID { get; set; }
        public string Saldo { get; set; }
        public Conta Conta { get; set; }

        public Cliente(string nome, string id, string saldo) 
        {
            Nome = nome;
            ID = id;
            Saldo = saldo;
        }
        public override string ToString()
        {
            return $"Nome: {Nome}, Id: {ID}, Saldo: {Saldo}";
        }
    }
}
