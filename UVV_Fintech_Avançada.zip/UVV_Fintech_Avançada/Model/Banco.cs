﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UVV_Fintech_Avançada.Model
{
    public class Banco
    {
        public List<Cliente> Clientes { get; set; }
        public List<Conta> Contas { get; set; }

        public Banco()
        {
            Clientes = new List<Cliente>();
            Contas = new List<Conta>();
        }

        public void AdicionarCliente(Cliente cliente)
        {
            Clientes.Add(cliente);
        }

        public void AdicionarConta(Conta conta)
        {
            Contas.Add(conta);
        }
    }
}
