﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace UVV_Fintech_Avançada
{
    public partial class MainWindow : Window
    {
        private List<Model.Cliente> clientes = new List<Model.Cliente>();
        public MainWindow()
        {
            InitializeComponent();
            AtualizarDataGrid();
        }

        private void buttonAplicativo_Click(object sender, RoutedEventArgs e)
        {
            Window1 novaJanela = new Window1();
            novaJanela.Show();
        }

        private void buttonAdd_Click(object sender, RoutedEventArgs e)
        {
            string nome = txtNome.Text;
            string id = txtID.Text;
            string saldo = txtSaldo.Text;

            if (!string.IsNullOrWhiteSpace(nome) && !string.IsNullOrWhiteSpace(id) && !string.IsNullOrWhiteSpace(saldo))
            {
                Model.Cliente novoCliente = new Model.Cliente(nome, id, saldo);
                clientes.Add(novoCliente);

                MessageBox.Show("Cliente cadastrado com sucesso!");
                LimparCampos();
                AtualizarDataGrid();
            }
            else
            {
                MessageBox.Show("Preencha todos os campos.");
            }
        }

        private void AtualizarDataGrid()
        {
            dgClientes.ItemsSource = null;
            dgClientes.ItemsSource = clientes;
        }
        private void LimparCampos()
        {
            txtNome.Clear();
            txtID.Clear();
            txtSaldo.Clear();
        }
    }
}