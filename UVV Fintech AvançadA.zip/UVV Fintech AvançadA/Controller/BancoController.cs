﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UVV_Fintech_AvançadA.Model;

namespace UVV_Fintech_AvançadA.Controller
{
    public class BancoController
    {
        private Banco banco;

        public BancoController(Banco banco)
        {
            this.banco = banco;
        }

        public void AdicionarCliente(string nome, Conta conta)
        {
            Cliente cliente = new Cliente(nome, conta);
            banco.AdicionarCliente(cliente);
        }

        public void ExecutarTransacao(ITransacao transacao, double valor)
        {
            transacao.Executar(valor);
        }

        public List<Cliente> ObterClientes()
        {
            return banco.Clientes;
        }

        public double ConsultarSaldo(Conta conta)
        {
            return conta.Saldo;
        }
    }
}
