﻿using System;
using System.Windows;
using UVV_Fintech_AvançadA.Controller;
using UVV_Fintech_AvançadA.Model;

namespace BancoApp
{
    public partial class MainWindow : Window
    {
        private BancoController bancoController;
        private Conta contaAtual;

        public MainWindow()
        {
            InitializeComponent();
            Banco banco = new Banco();
            bancoController = new BancoController(banco);

            // Exemplo de inicialização
            contaAtual = new ContaCorrente(1);
            bancoController.AdicionarCliente("João", contaAtual);
        }

        private void Depositar_Click(object sender, RoutedEventArgs e)
        {
            double valor = Convert.ToDouble(ValorTransacao.Text);
            bancoController.ExecutarTransacao(new DepositarTransacao(contaAtual), valor);
            MessageBox.Show("Depósito realizado com sucesso!");
        }

        private void Sacar_Click(object sender, RoutedEventArgs e)
        {
            double valor = Convert.ToDouble(ValorTransacao.Text);
            try
            {
                bancoController.ExecutarTransacao(new SacarTransacao(contaAtual), valor);
                MessageBox.Show("Saque realizado com sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void ConsultarSaldo_Click(object sender, RoutedEventArgs e)
        {
            double saldo = bancoController.ConsultarSaldo(contaAtual);
            Saldo.Text = saldo.ToString("C");
        }
    }
}
