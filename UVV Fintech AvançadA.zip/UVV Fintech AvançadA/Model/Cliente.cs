﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UVV_Fintech_AvançadA.Model
{
    public class Cliente
    {
        public string Nome { get; set; }
        public Conta Conta { get; set; }

        public Cliente(string nome, Conta conta)
        {
            Nome = nome;
            Conta = conta;
        }
    }
}
