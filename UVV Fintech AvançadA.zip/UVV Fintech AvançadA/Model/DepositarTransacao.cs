﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UVV_Fintech_AvançadA.Model
{
    public class DepositarTransacao : ITransacao
    {
        private Conta conta;

        public DepositarTransacao(Conta conta)
        {
            this.conta = conta;
        }

        public void Executar(double valor)
        {
            conta.Depositar(valor);
        }
    }
}
