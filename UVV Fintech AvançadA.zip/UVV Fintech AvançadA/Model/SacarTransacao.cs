﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UVV_Fintech_AvançadA.Model
{
    public class SacarTransacao : ITransacao
    {
        private Conta conta;

        public SacarTransacao(Conta conta)
        {
            this.conta = conta;
        }

        public void Executar(double valor)
        {
            conta.Sacar(valor);
        }
    }
}
