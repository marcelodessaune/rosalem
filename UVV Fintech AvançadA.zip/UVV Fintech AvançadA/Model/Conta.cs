﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UVV_Fintech_AvançadA.Model
{
    public abstract class Conta
    {
        public int Numero { get; set; }
        public double Saldo { get; protected set; }

        public Conta(int numero)
        {
            Numero = numero;
            Saldo = 0;
        }

        public virtual void Depositar(double valor)
        {
            Saldo += valor;
        }

        public virtual void Sacar(double valor)
        {
            if (Saldo >= valor)
                Saldo -= valor;
            else
                throw new System.Exception("Saldo insuficiente");
        }
    }
}
